# treinar_modelo.py
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
import joblib

# Carrega os dados
df = pd.read_csv('dados_libras.csv')

# Balanceamento por undersampling (igualar as classes à menor quantidade)
min_count = df['label'].value_counts().min()
df = df.groupby('label', group_keys=False).apply(lambda x: x.sample(min_count, random_state=42)).reset_index(drop=True)

print("Contagem das classes após balanceamento:")
print(df['label'].value_counts())

# Define X e y
X = df.drop('label', axis=1)
y = df['label']

# Normalização
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Checa se todas as classes têm pelo menos 2 amostras para usar stratify
if all(df['label'].value_counts() >= 2):
    stratify_param = y
else:
    print("⚠️ Algumas classes têm menos de 2 amostras; stratify desabilitado.")
    stratify_param = None

# Divide treino/teste
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=stratify_param
)

# Treina RandomForest com balanceamento interno
clf = RandomForestClassifier(class_weight='balanced')
clf.fit(X_train, y_train)

# Avalia o modelo
print(f"\n✅ Acurácia: {clf.score(X_test, y_test):.2f}")
print("\n📊 Relatório por classe:\n")
print(classification_report(y_test, clf.predict(X_test)))

# Salva modelo e scaler
joblib.dump(clf, 'modelo_libras.pkl')
joblib.dump(scaler, 'scaler.pkl')