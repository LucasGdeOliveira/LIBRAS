# coletor_libras.py
import cv2
import mediapipe as mp
import os

letra = 'S'  # 🔤 Altere para a letra desejada 'LUCAS'
salvar_pasta = f'dataset/{letra}'
os.makedirs(salvar_pasta, exist_ok=True)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)
contador = 0
limite = 300

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(rgb)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            h, w, _ = frame.shape
            x_min = int(min([lm.x for lm in hand_landmarks.landmark]) * w) - 20
            y_min = int(min([lm.y for lm in hand_landmarks.landmark]) * h) - 20
            x_max = int(max([lm.x for lm in hand_landmarks.landmark]) * w) + 20
            y_max = int(max([lm.y for lm in hand_landmarks.landmark]) * h) + 20

            x_min, y_min = max(x_min, 0), max(y_min, 0)
            x_max, y_max = min(x_max, w), min(y_max, h)
            cropped = frame[y_min:y_max, x_min:x_max]

            if cropped.size > 0:
                cropped = cv2.resize(cropped, (200, 200))
                nome_arquivo = os.path.join(salvar_pasta, f'{letra}_{contador+1}.jpg')
                cv2.imwrite(nome_arquivo, cropped)
                contador += 1

            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            cv2.rectangle(frame, (x_min, y_min), (x_max, y_max), (0, 255, 0), 2)

    cv2.putText(frame, f'Letra: {letra} | Imagens: {contador}/{limite}', (10, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
    cv2.imshow('Captura de Libras', frame)

    if cv2.waitKey(1) & 0xFF == 27 or contador >= limite:
        break

cap.release()
cv2.destroyAllWindows()
