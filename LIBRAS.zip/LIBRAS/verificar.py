# verificar_dataset.py
import os
from collections import Counter

base_path = 'dataset'
contagem = {}

for pasta in os.listdir(base_path):
    total = len(os.listdir(os.path.join(base_path, pasta)))
    contagem[pasta] = total

print("🧮 Contagem de imagens por letra:")
print(dict(sorted(contagem.items())))
