import pandas as pd
df = pd.read_csv('dados_libras.csv')
print(df['label'].value_counts())


