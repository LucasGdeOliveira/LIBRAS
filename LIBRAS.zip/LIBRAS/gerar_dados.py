# gerar_dados.py
import os
import cv2
import mediapipe as mp
import pandas as pd
import numpy as np

pastas = ['L', 'U', 'C', 'A', 'S']
base_path = 'dataset'

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=True)

data, labels = [], []
erros = 0
sucesso = 0

for letra in pastas:
    path_letra = os.path.join(base_path, letra)
    for img_nome in os.listdir(path_letra):
        img_path = os.path.join(path_letra, img_nome)
        img = cv2.imread(img_path)
        if img is None:
            erros += 1
            continue
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        results = hands.process(img_rgb)

        if results.multi_hand_landmarks:
            for hand in results.multi_hand_landmarks:
                if len(hand.landmark) == 21:
                    pontos = []
                    base_x, base_y, base_z = hand.landmark[0].x, hand.landmark[0].y, hand.landmark[0].z

                    for lm in hand.landmark:
                        pontos.extend([lm.x - base_x, lm.y - base_y, lm.z - base_z])

                    pontos = np.array(pontos)
                    norm = np.linalg.norm(pontos)
                    if norm == 0:
                        erros += 1
                        continue

                    data.append((pontos / norm).tolist())
                    labels.append(letra)
                    sucesso += 1
        else:
            erros += 1

df = pd.DataFrame(data)
df['label'] = labels
df.to_csv('dados_libras.csv', index=False)
print(f"✅ CSV 'dados_libras.csv' salvo com sucesso!")
print(f"✅ Amostras válidas: {sucesso}")
print(f"⚠️ Amostras descartadas: {erros}")
